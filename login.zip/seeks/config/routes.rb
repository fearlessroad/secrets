Rails.application.routes.draw do
  get 'session/new'

	root 'users#index'
	post '/session/create' => 'session#create'
	get '/users/:id' => 'users#show'
end
