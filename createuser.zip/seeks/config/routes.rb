Rails.application.routes.draw do
  get 'session/new'

	root 'users#index'
	post '/session/create' => 'session#create'
	post '/users/create' => 'users#create'
	get '/users/new' => 'users#new'
	get '/users/:id' => 'users#show'
	delete '/session'=>'session#delete'
end
